###############################################################################
#                                                                             #
# Copyright (C) 2004-2008 Edward d'Auvergne                                   #
#                                                                             #
# This file is part of the program relax.                                     #
#                                                                             #
# relax is free software; you can redistribute it and/or modify               #
# it under the terms of the GNU General Public License as published by        #
# the Free Software Foundation; either version 2 of the License, or           #
# (at your option) any later version.                                         #
#                                                                             #
# relax is distributed in the hope that it will be useful,                    #
# but WITHOUT ANY WARRANTY; without even the implied warranty of              #
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               #
# GNU General Public License for more details.                                #
#                                                                             #
# You should have received a copy of the GNU General Public License           #
# along with relax; if not, write to the Free Software                        #
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA   #
#                                                                             #
###############################################################################

# Script for relaxation curve fitting.
######################################


# Create the 'rx' data pipe.
pipe.create('rx', 'relax_fit')

# Load the backbone amide 15N spins from a PDB file.
structure.read_pdb('ubi')
structure.load_spins(spin_id='@N')

# Spectrum names.
names = [
    'Ub-T1_20ms',
    'Ub-T1_50ms1',
    'Ub-T1_50ms2',
    'Ub-T1_100ms',
    'Ub-T1_200ms',
    'Ub-T1_300ms',
    'Ub-T1_400ms',
    'Ub-T1_600ms',
    'Ub-T1_900ms',
    'Ub-T1_1200ms'
]

# Relaxation times (in seconds).
times = [
    0.02,
    0.05,
    0.05,
    0.100,
    0.200,
    0.300,
    0.400,
    0.600,
    0.900,
    1.200
]

# Loop over the spectra.
for i in xrange(len(names)):
    # Load the peak intensities.
    spectrum.read_intensities(file=names[i]+'.list', dir='.', spectrum_id=names[i], int_method='height')

    # Set the relaxation times.
    relax_fit.relax_time(time=times[i], spectrum_id=names[i])

# Specify the duplicated spectra.
spectrum.replicated(spectrum_ids=['Ub-T1_50ms1', 'Ub-T1_50ms2'])

# Peak intensity error analysis.
spectrum.error_analysis()

# Deselect unresolved spins.
#deselect.read(file='unresolved')

# Set the relaxation curve type.
relax_fit.select_model('exp')

# Grid search.
grid_search(inc=11)

# Minimise.
minimise('simplex', scaling=False, constraints=False)

# Monte Carlo simulations.
monte_carlo.setup(number=500)
monte_carlo.create_data()
monte_carlo.initial_values()
minimise('simplex', scaling=False, constraints=False)
monte_carlo.error_analysis()

# Save the relaxation rates.
value.write(param='rx', file='rx.out', force=True)

# Save the results.
results.write(file='results-r1', force=True)

# Create Grace plots of the data.
#grace.write(y_data_type='chi2', file='chi2.agr', force=True)    # Minimised chi-squared value.
#grace.write(y_data_type='i0', file='i0.agr', force=True)    # Initial peak intensity.
#grace.write(y_data_type='rx', file='rx.agr', force=True)    # Relaxation rate.
#grace.write(x_data_type='relax_times', y_data_type='int', file='intensities.agr', force=True)    # Average peak intensities.
#grace.write(x_data_type='relax_times', y_data_type='int', norm=True, file='intensities_norm.agr', force=True)    # Average peak intensities (normalised).

# Display the Grace plots.
#grace.view(file='chi2.agr')
#grace.view(file='i0.agr')
#grace.view(file='rx.agr')
#grace.view(file='intensities.agr')
#grace.view(file='intensities_norm.agr')

# Save the program state.
state.save('r1.save', force=True)
